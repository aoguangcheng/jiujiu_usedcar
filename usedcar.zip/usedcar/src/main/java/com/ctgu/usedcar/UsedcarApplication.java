package com.ctgu.usedcar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsedcarApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsedcarApplication.class, args);
	}

}
